<?php
require_once 'connection.php';
require_once ('style.php');
require_once ('menu.php');

$conn = mysqli_connect("localhost", "root", "") or die(mysqli_error($conn));
$db = mysqli_select_db($conn, "prajituri") or die(mysqli_error($conn));
$queryData = mysqli_query($conn, "SELECT * FROM prajituri ") or mysqli_error($conn);

if (isset($_POST['delete'])) {

    $sql = "CALL deletePrajituri('" . $_POST["nume"] . "')";
    $q = $con->query($sql);
    if ($q) {
        echo "<b>Datele au fost sterse cu succes !!!</b>";
    } else {
        echo"Vai vai vai";
    }
}
?>   
<!DOCTYPE html>
<html>
    <head>

        <title>Delete</title>
        <style type="text/css">

            .button {
                display: inline-block;
                padding: 10px 15px;
                font-size: 12px;
                cursor: pointer;
                text-align: center;
                text-decoration: none;
                outline: none;
                color: #fff;
                background-color:#FFD700;
                border: none;
                border-radius: 5px;
                box-shadow: 0 2px #999;
            }

            .button:hover {background-color: black}

            .button:active {
                background-color: #DAA520;
                box-shadow: 0 5px #666;
                transform: translateY(4px);
            }
            .control-group {
                display: inline-block;
                vertical-align: top;
                background: red;
                text-align: left;
                box-shadow: 0 1px 2px rgba(0,0,0,0.1);
                padding: 30px;
                width: 200px;
                height: 210px;
                margin: 10px;
            }
            .control {
                display: block;
                position: relative;
                padding-left: 30px;
                margin-bottom: 15px;
                cursor: pointer;
                font-size: 18px;
            }
            .control input {
                position: absolute;
                z-index: -1;
                opacity: 0;
            }
            .control__indicator {
                position: absolute;
                top: 2px;
                left: 0;
                height: 20px;
                width: 20px;
                background: #e6e6e6;
            }
            .control--radio .control__indicator {
                border-radius: 50%;
            }
            .control:hover input ~ .control__indicator,
            .control input:focus ~ .control__indicator {
                background: red;
            }
            .control input:checked ~ .control__indicator {
                background: red;
            }
            .control:hover input:not([disabled]):checked ~ .control__indicator,
            .control input:checked:focus ~ .control__indicator {
                background: red;
            }
            .control input:disabled ~ .control__indicator {
                background: #e6e6e6;
                opacity: 0.6;
                pointer-events: none;
            }
            .control__indicator:after {
                content: '';
                position: absolute;
                display: none;
            }
            .control input:checked ~ .control__indicator:after {
                display: block;
            }
            .control--checkbox .control__indicator:after {
                left: 8px;
                top: 4px;
                width: 3px;
                height: 8px;
                border: solid #fff;
                border-width: 0 2px 2px 0;
                transform: rotate(45deg);
            }
            .control--checkbox input:disabled ~ .control__indicator:after {
                border-color: red;
            }

        </style>
    </head>
    <body>

        <form action="delete.php" method="POST">
            <br></br>
            <table whidth="100%"> 
                <thead>
                    <tr style="background-color:red" >
                        <td><b>Nume</b></td>
                        <td><b>Categorie</b></td> 
                        <td><b>Ingrediente</b></td> 
                        <td><b>Pret</b></td> 

                        <td align="center">
                            <div><input type="submit" name="delete" value="&#350;tergere multipl&#259;" class="button"></div> 

                        </td>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_array($queryData)) { ?>
                        <tr>
                            <td><?php echo $row['nume'] ?></td>
                            <td><?php echo $row['categorie'] ?></td> 
                            <td><?php echo $row['ingrediente'] ?></td> 
                            <td><?php echo $row['pret'] ?></td> 

                            <td align="center">
                                <label class="control control--checkbox">
                                    <input type="checkbox" name="nume"value="<?php echo $row['nume']; ?>">
                                    <div class="control__indicator"></div>
                                </label>

                            </td>

                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </form>
    </body>
</html>
</html>