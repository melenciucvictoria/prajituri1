<!DOCTYPE html>
<html>
    <head>
        <title>Prajituri</title>
        <style type="text/css">
            body{margin:0 auto; width:980px; position:relative;}
            div.navMENU{width:100%; height:50px;}
            div.navMENU ul{list-style-type:none; padding:0px; margin:0 auto;}
            div.navMENU li{float:left; padding:0px; margin:0px;}
            div.navMENU a{display:block; width:180px; border-radius:10px; -moz-border-radius:10px;-webkit-border:10px;}
            a:link{lont-weight:bold; color:red; background-color:red; text-align:center; text-decoration:none;padding:5px;}
            a:hover{background-color:red;}
        </style>
        <style>
            table{
                width:100%;
            }
            table, th, td{
                border:1px solid #DC143C;
                border-collapse:collapse;
            }
            th, td{
                padding:5px;
                text-align: left;
            }
            table#t01 tr:nth-child(even){
                background-color:#F0F8FF;
            }
            table#t01 tr:nth-child(odd){
                background-color:#E0FFFF;
            }
            table#t01 th{
                background-color:#008000; color:white;
            }

        </style>
    </head>
</html>
