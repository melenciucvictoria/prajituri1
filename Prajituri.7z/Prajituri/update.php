<?php
require_once ('style.php');
require_once ('menu.php');
$conn = mysqli_connect("localhost", "root", "") or die(mysqli_error($conn));
$db = mysqli_select_db($conn, "prajituri") or die(mysqli_error($conn));
$queryData = mysqli_query($conn, "SELECT * FROM prajituri ") or mysqli_error($conn);
?>   
<!DOCTYPE html>
<html>
    <head>

        <title>Update</title>
    </head>
    <body>

        <form action="update.php" method="POST">
            <table whidth="100%"> 
                <thead>
                    <tr style="background-color:red" >
                        <td><b>Nume</b></td>
                        <td><b>Categorie</b></td> 
                        <td><b>Ingrediente</b></td> 
                        <td><b>Pret</b></td> 

                        <td align="center">
                            Update
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_array($queryData)) { ?>
                        <tr>
                            <td><?php echo $row['nume'] ?></td>
                            <td><?php echo $row['categorie'] ?></td> 
                            <td><?php echo $row['ingrediente'] ?></td> 
                            <td><?php echo $row['pret'] ?></td> 

                            <td align="center">

                                <a href="edit1.php?edit=<?php echo$row["nume"]; ?>"> edit</a>

                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </form>
    </body>
</html>
