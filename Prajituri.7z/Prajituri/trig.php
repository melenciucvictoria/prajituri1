<?php

$hostname = 'localhost';
$username = 'root';
$password = '';
try {
    $dbh = new PDO("mysql:host=$hostname;dbname=prajituri", $username, $password);
    echo 'Connected to database<br/>';
    $sql = "SELECT * FROM prajituri";
    foreach ($dbh->query($sql)as $row) {
        print $row['nume'] . '-' . $row['categorie'] . '-' . $row['ingrediente'] . '-' . $row['pret'] . '<br/>';
    }
    $dbh = null;
} catch (PDOException $e) {
    echo $e->getMessage();
}
?>
<?php

$sql = "CREATE TRIGGER MysqlTrigger2 BEFORE  UPDATE ON prajituri FOR EACH ROW  BEGIN SET NEW.nume=UPPER(NEW.nume);END;";
$stmt = $dbh->prepare($sql);
$stmt->execute();
?>
