<!DOCTYPE html>
<html>
    <body>
        <?php
        require_once ('style.php');
        require_once ('menu.php');
        $con = mysqli_connect("localhost", "root", "") or die(mysqli_error($con));
        $db = mysqli_select_db($con, "prajituri") or die(mysqli_error($con));
        $queryData = mysqli_query($con, "SELECT * FROM prajituri ") or mysqli_error($con);
        if (isset($_POST["submit"])) {
    $sql3 = "CALL updatePrajituri('" . $_POST["nume"] . "','" . $_POST["categorie"] . "','" . $_POST["ingrediente"] . "','" . $_POST["pret"] . "')";
    $q = $con->query($sql3);
    if ($q) {
        echo "Datele au fost actualizate cu succes";
    } else {
        echo "Vai vai vai";
    }
}

echo "<br><br>";
echo "<table border='1'>
    <tr>
<th>Nume</th>
<th>Categorie</th>
<th>Ingrediente</th>
<th>Pret</th>
</tr>
<br/><br/>";

$sql4 = "SELECT * FROM prajituri";
foreach ($con->query($sql4) as $row) {
    echo "<tr>";
    echo "<td>" . $row['nume'] . "</td>";
    echo "<td>" . $row['categorie'] . "</td>";
    echo "<td>" . $row['ingrediente'] . "</td>";
    echo "<td>" . $row['pret'] . "</td>";
}


        if (isset($_GET['edit'])) {
            $nume = $_GET['edit'];
            $categorie = $_GET['edit'];
            $ingrediente = $_GET['edit'];
            $Pret = $_GET['edit'];
            $queryData = mysqli_query($con, "SELECT * FROM prajituri WHERE nume='$nume'");
            $row = mysqli_num_rows($queryData);
        }
        if (isset($_POST['categorie'])) {
            $categorie = $_POST['categorie'];
            $nume = $_POST['nume'];
            $sql = "UPDATE prajituri SET categorie='$categorie' WHERE nume='$nume' ";
            $res = mysqli_query($con, $sql) or die("Nu s-au schimbat datele" . mysqli_eror($conn));
            echo"<meta http-equiv='refresh' content='0';url=edit1.php'>";
        }
        if (isset($_POST['ingrediente'])) {
            $ingrediente = $_POST['ingrediente'];
            $nume = $_POST['nume'];
            $sql = "UPDATE prajituri SET ingrediente='$ingrediente' WHERE ='$nume'";
            $res = mysqli_query($con, $sql) or die("Nu s-au schimbat datele" . mysqli_eror($conn));
            echo"<meta http-equiv='refresh' content='0;url=edit1.php'>";
        }
       
        ?>
        <?php while ($row = mysqli_fetch_array($queryData)) { ?>
 <style type="text/css">

            .button {
            display: inline-block;
            padding: 15px 25px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            outline: none;
            color: #fff;
            background-color:#FFD700;
            border: none;
            border-radius: 7px;
            box-shadow: 0 9px #999;
        }

        .button:hover {background-color: black}

        .button:active {
            background-color: #DAA520;
            box-shadow: 0 5px #666;
            transform: translateY(4px);
        }
            </style>
        <form action="uppdate.php" method="POST">

                <b><font face="Monotype Corsiva" color="red" size="5">Schimb&#259;  datele din &#238;nregistrare</b><br><br>
                <p><font face="Monotype Corsiva" color="red" size="5">Nume: &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;<input type="text" name="nume" size="70" value="<?php echo $row['nume']; ?>"</></p> 
                <p><font face="Monotype Corsiva" color="red" size="5">Categorie: &#160;&#160;
                    <input type="text" name="categorie" value="<?php echo $row['categorie']; ?>" size="70" </>
                </p>
                <p><font face="Monotype Corsiva" color="red" size="5">Ingrediente:
                    <input type="text" name="ingrediente" size="70" value="<?php echo $row['ingrediente']; ?>"</>
                </p>
                <p><font face="Monotype Corsiva" color="red" size="5">Pret: &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
                    <input type="text" name="pret" size="70" value="<?php echo $row['pret']; ?>"</>
                </p>
                <input type="submit" name="submit" value="Schimba" class="button"/>
            </p>
<?php } ?>

    </form>
</body>
</html>