<?php
try {
    $con = new PDO('mysql:host=localhost;dbname=prajituri', 'root', '');

    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection Failed';
}

$pret = $_GET('ingrediente');
$show = $con->query("SELECT * FROM 'prajituri' WHERE pret='pret'");
$row = $show->fetch()
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>

    <body>
        <form method="POST">
            <input type="text" name="text"/><br/><br/>
            <input type="text" name="value"/><br/><br/>
            <input type="submit" name="send" value="send data"/>
        </form>
    </body>
</html>