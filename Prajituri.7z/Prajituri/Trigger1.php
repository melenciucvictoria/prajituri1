<?php

$con = mysqli_connect("localhost", "root", "", "prajituri")or die('Could not connect: ' . mysqli_error($con));
echo "<h2>MySQL:Simple Select statement </h2>";
$result = mysqli_query($con, "SELECT * FROM prajituri");
echo "<table border ='1'>
    <tr>
<th>Nume</th>
<th>Categorie</th>
<th>Ingrediente</th>
<th>Pret</th>
</tr>";
while ($prajitura = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $prajitura['nume'] . "</td>";
    echo "<td>" . $prajitura['categorie'] . "</td>";
    echo "<td>" . $prajitura['ingrediente'] . "</td>";
    echo "<td>" . $prajitura['pret'] . "</td>";
    echo "</tr>";
}
echo "</table>";
echo "<h2>CREATE MySQL Trigger in PHP</h2>";

$sql = "CREATE TRIGGER MysqlTrigger1 BEFORE  UPDATE ON prajituri FOR EACH ROW  BEGIN SET NEW.nume=UPPER(NEW.nume);END;";

highlight_string("CREATE TRIGGER MysqlTrigger1 BEFORE  UPDATE ON prajituri FOR EACH ROW  BEGIN SET NEW.nume=UPPER(NEW.nume);");
mysqli_query($con, $sql);
echo "<h2>MySQL:INSERT Statement </h2>";
$qry = mysqli_query($con, "INSERT INTO prajituri (nume,categorie,ingrediente,pret) VALUES ('pra','ma','n','14')");
highlight_string("INSERT INTO prajituri (nume,categorie,ingrediente,pret) VALUES ('pra','ma','n','14')");
echo "<br><br/>Value is be inserted";
mysqli_query($con, $qry);
echo "<h2>MySQL:Effect of the Trigger</h2>";
$result = mysqli_query($con, "SELECT * from prajituri");
echo "<table border = '1'>
<tr>
<th>Nume</th>
<th>Categorie</th>
<th>Ingrediente</th>
<th>Pret</th>
</tr>";

while ($prajitura = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $prajitura['nume'] . "</td>";
    echo "<td>" . $prajitura['categorie'] . "</td>";
    echo "<td>" . $prajitura['ingrediente'] . "</td>";
    echo "<td>" . $prajitura['pret'] . "</td>";
    echo "</tr>";
}
echo "</table>";
