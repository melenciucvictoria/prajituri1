<?php
require_once ('style.php');
require_once ('menu.php');
require_once ('connection.php');
if (isset($_POST['chk_group'])) {
    $optionArray = $_POST['chk_group'];
    for ($i = 0; $i < count($optionArray); $i++) {
        echo $optionArray[$i] . "<br />";
    }
}
?>
<html>
    <style type="text/css">
        .button {
            display: inline-block;
            padding: 15px 25px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            outline: none;
            color: #fff;
            background-color:#FFD700;
            border: none;
            border-radius: 7px;
            box-shadow: 0 9px #999;
        }

        .button:hover {background-color: black}

        .button:active {
            background-color: #DAA520;
            box-shadow: 0 5px #666;
            transform: translateY(4px);
        }
        .control-group {
            display: inline-block;
            vertical-align: top;
            background: red;
            text-align: left;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            padding: 30px;
            width: 200px;
            height: 210px;
            margin: 10px;
        }
        .control {
            display: block;
            position: relative;
            padding-left: 30px;
            margin-bottom: 15px;
            cursor: pointer;
            font-size: 18px;
        }
        .control input {
            position: absolute;
            z-index: -1;
            opacity: 0;
        }
        .control__indicator {
            position: absolute;
            top: 2px;
            left: 0;
            height: 20px;
            width: 20px;
            background: #e6e6e6;
        }
        .control--radio .control__indicator {
            border-radius: 50%;
        }
        .control:hover input ~ .control__indicator,
        .control input:focus ~ .control__indicator {
            background: red;
        }
        .control input:checked ~ .control__indicator {
            background: red;
        }
        .control:hover input:not([disabled]):checked ~ .control__indicator,
        .control input:checked:focus ~ .control__indicator {
            background: red;
        }
        .control input:disabled ~ .control__indicator {
            background: #e6e6e6;
            opacity: 0.6;
            pointer-events: none;
        }
        .control__indicator:after {
            content: '';
            position: absolute;
            display: none;
        }
        .control input:checked ~ .control__indicator:after {
            display: block;
        }
        .control--checkbox .control__indicator:after {
            left: 8px;
            top: 4px;
            width: 3px;
            height: 8px;
            border: solid #fff;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }
        .control--checkbox input:disabled ~ .control__indicator:after {
            border-color: red;
        }

    </style>
    <head>
        <title> Selectare campuri</title>
    </head>
    <form action="select2.php" method="POST">
        <BR><BR>
        <label class="control control--checkbox"><font face="Monotype Corsiva" color="red" size="5">Nume
            <input type="checkbox" name="chk_group[]" value="nume" />
            <div class="control__indicator"></div>
        </label>

        <label class="control control--checkbox"><font face="Monotype Corsiva" color="red" size="5">Categorie
            <input type="checkbox" name="chk_group[]" value="categorie" />
            <div class="control__indicator"></div>
        </label>

        <label class="control control--checkbox"><font face="Monotype Corsiva" color="red" size="5">Ingrediente
            <input type="checkbox" name="chk_group[]" value="ingrediente" />
            <div class="control__indicator"></div>
        </label>

        <label class="control control--checkbox"><font face="Monotype Corsiva" color="red" size="5">Pret
            <input type="checkbox" name="chk_group[]" value="pret" />
            <div class="control__indicator"></div>
        </label>

        <input type="submit" name='submit' value='Selecteaz&#259;' class="button"/>
    </form>
</html>

