<?php
require_once ('style.php');
require_once ('menu.php');
require_once 'connection.php';
$sql = 'CALL GetPrajituri()';
$q = $con->query($sql);
$q->setFetchMode(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
    <head>

        <title>Edit</title>
    </head>
    <body>


        <table whidth="100%"> 
            <thead>
            <br></br>
            <table>
                <tr style="background-color:red" >
                    <th>Nume</th>
                    <th>Categorie</th>
                    <th>Ingrediente</th>
                    <th>Pret</th>
                    <th>Update</th>
                </tr>
                </thead>
                <tbody>
                    <?php while ($res = $q->fetch()): ?>
                        <tr>
                            <td><?php echo $res['nume']; ?></td>
                            <td><?php echo $res['categorie']; ?></td>
                            <td><?php echo $res['ingrediente']; ?></td>
                            <td><?php echo $res['pret']; ?></td>
                            <td align="center"><?php echo"  <a href='uppdate.php?edit=$res[nume]'>edit</a> " ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
            </table>
        </form>
</body>
</html>
</html>



