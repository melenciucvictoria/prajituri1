<?php

require_once ('style.php');
require_once ('menu.php');
require_once 'connection.php';
echo "<table border='1'>";

echo '<tr style="background-color:red" >';
echo"<th>Nume</th>";
echo"<th>Categorie</th>";
echo"<th>Ingrediente</th>";
echo"<th>Pret</th>";
echo"</tr>";
echo"<br/><br/>";

$sql = "SELECT * FROM prajituri";
foreach ($con->query($sql)as $row) {
    echo "<tr>";
    echo "<td>" . $row['nume'] . "</td>";
    echo "<td>" . $row['categorie'] . "</td>";
    echo "<td>" . $row['ingrediente'] . "</td>";
    echo "<td>" . $row['pret'] . "</td>";
}