<?php
require_once 'connection.php';
require_once ('style.php');
require_once ('menu.php');
if (isset($_POST["submit"])) {
    $sql3 = "CALL insertPrajituri('" . $_POST["nume"] . "','" . $_POST["categorie"] . "','" . $_POST["ingrediente"] . "','" . $_POST["pret"] . "')";
    $q = $con->query($sql3);
    if ($q) {
        echo "<b>Datele au fost inserate cu succes<b>";
    } else {
        echo "Vai vai vai";
    }
}
echo "<table border='1'>";

echo '<tr style="background-color:red" >';
echo"<th>Nume</th>";
echo"<th>Categorie</th>";
echo"<th>Ingrediente</th>";
echo"<th>Pret</th>";
echo"</tr>";
echo"<br/><br/>";


$sql4 = "SELECT * FROM prajituri";
foreach ($con->query($sql4) as $row) {
    echo "<tr>";
    echo "<td>" . $row['nume'] . "</td>";
    echo "<td>" . $row['categorie'] . "</td>";
    echo "<td>" . $row['ingrediente'] . "</td>";
    echo "<td>" . $row['pret'] . "</td>";
}
?>

<!DOCTYPE html>
<html>
    <style type="text/css">
        .button {
            display: inline-block;
            padding: 12px 20px;
            font-size: 12px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            outline: none;
            color: #fff;
            background-color:#FFD700;
            border: none;
            border-radius: 7px;
            box-shadow: 0 9px #999;
        }

        .button:hover {background-color: black}

        .button:active {
            background-color: #DAA520;
            box-shadow: 0 5px #666;
            transform: translateY(4px);
        }
    </style>
    <body>


        <form action="insert.php" method="POST">
            <h1>  <font face="Monotype Corsiva" color="red" size="5"><b>Adauga o noua inregistrare<b></></h1>
                        <p><font face="Monotype Corsiva" color="red" size="5">Nume:&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
                            <input type="text" name="nume" size="70" value=""</>
                        </p>

                        <p><font face="Monotype Corsiva" color="red" size="5">Categorie:&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
                            <input type="text" name="categorie" size="70" value=""</>
                        </p>

                        <p><font face="Monotype Corsiva" color="red" size="5">Ingrediente:&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
                            <input type="text" name="ingrediente" size="70" value=""</>

                        </p>
                        <p><font face="Monotype Corsiva" color="red" size="5">Pret:&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
                            <input type="text" name="pret" size="70" value=""</>
                        </p>
                        <p>
                            <input type="submit" name="submit" value="Adauga" style="font-size:20px" class="button"/>
                        </p>

                        </body>
                        </body>
                        </html>