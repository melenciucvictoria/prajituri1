<?php

require_once ('style.php');
require_once ('menu.php');
$sql = "SELECT ";
$a = $_POST['chk_group'];
for ($i = 0; $i < count($a) - 1; $i++) {
    $sql .= " " . $a[$i] . ", ";
}
$sql .= $a[count($a) - 1] . " FROM prajituri";
$db = mysqli_connect("localhost", "root", "");
mysqli_select_db($db, "prajituri");
$result = mysqli_query($db, $sql);

echo "<TABLE Border=30 width=80% cellspacing=10>";
echo '<tr style="background-color:red">';
foreach ($a as $v)
    echo "<td><b>" . $v . "</b></td>";
echo "</tr>";
while ($myrow = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
    echo "<TR>";
    foreach ($a as $v)
        echo "<td>" . $myrow[$v] . "</td>";
    echo "</tr>";
}
echo "</TABLE>";
?>