<html>
    <body background="01.jpg" BGPROPETIES="fixed">
        <div class="navMENU">
            <h1 style="text-align:center ;color:red"><marquee behavior="alternate"> Bine a&#355;i venit!!!</marquee></h1>
            <hr/>
            <ul>
                <li><a href="index.php">ACAS&#258;</a> </li>
                <li><a href="select.php">SELECT</a> </li>
                <li><a href="delete.php">DELETE</a> </li>
                <li> <a href="edit1.php">UPDATE</a> </li>
                <li><a href="insert.php">INSERT</a> </li>
            </ul>
        </div><br><br><br><br>
    </<body>
</html>
